@extends('frontend.master')

@section('maincontent')
<style>
    #fontcss{
        font-size: 30px;
    }

    @media only screen and (max-width: 600px) {
        #fontcss{
            font-size: 20px;
        }
    }
</style>

<div style="padding-top:60px;padding-bottom:100px" class="body-content">

    <div class="container">
        <div class="row">
            <div class="col-md-12" style="text-align: center;">
                <p class="p-0 pb-2 m-0" style="color: black;font-size: 22px;">Call Center</p>
                <a href="telto:+88{{ App\Models\Basicinfo::first()->phone_one }}">
                    <button class="btn btn-danger" style="background:#FF5000;border-radius: 6px;"> <i class="fa fa-phone-alt" id="fontcss"></i> {{ App\Models\Basicinfo::first()->phone_one }}</button>
                </a>
            </div>
        </div>
    </div>
    <div class="container pt-4 mt-4">
        <div class="row">
            <div class="col-md-12" style="text-align: center;">
                <p class="p-0 pb-2 m-0" style="color: black;font-size: 22px;">Mail Us</p>
                <a href="mail:{{ App\Models\Basicinfo::first()->email }}">
                    <button class="btn btn-danger" style="background:#003687;border:1px solid #003687; border-radius: 6px;" id="fontcss"> <i class="fa fa-envelope"></i> {{ App\Models\Basicinfo::first()->email }}</button>
                </a>
            </div>
        </div>
    </div>
    <div class="container pt-4 mt-4">
        <div class="row">
            <div class="col-md-12" style="text-align: center;">
                <p class="p-0 pb-2 m-0" style="color: black;font-size: 22px;">Our Page</p>
                <a href="https://www.facebook.com/selfshop.reseller">
                    <button class="btn btn-danger" style="background:#613EEA;border:1px solid #613EEA; border-radius: 6px;" id="fontcss"> <img src="{{ asset('public/facebook.png') }}" alt="" style="width: 45px;"> /selfshop.reseller</button>
                </a>
            </div>
        </div>
    </div>

    <div class="container pt-4 mt-4">
        <div class="row">
            <div class="col-md-12" style="text-align: center;">
                <p class="p-0 pb-2 m-0" style="color: black;font-size: 22px;">Facebook Group</p>
                <a href="https://www.facebook.com/groups/selfshopltd">
                    <button class="btn btn-danger" style="background:#613EEA;border:1px solid #613EEA; border-radius: 6px;" id="fontcss"> <img src="{{ asset('public/facebook.png') }}" alt="" style="width: 45px;"> /groups/selfshopltd</button>
                </a>
            </div>
        </div>
    </div>

    <div class="container pt-4 mt-4">
        <div class="row">
            <div class="col-md-12" style="text-align: center;">
                <p class="p-0 pb-2 m-0" style="color: black;font-size: 22px;">Messanger Group</p>
                <a href="https://www.facebook.com/selfshop.reseller">
                    <button class="btn btn-danger" style="background:#613EEA;border:1px solid #613EEA; border-radius: 6px;" id="fontcss"> <img src="{{ asset('public/messenger.png') }}" alt="" style="width: 35px;"> /m.selfshop.reseller</button>
                </a>
            </div>
        </div>
    </div>
    <div class="container pt-4 mt-4">
        <div class="row">
            <div class="col-md-12" style="text-align: center;">
                <p class="p-0 pb-2 m-0" style="color: black;font-size: 22px;">What's App Group</p>
                <a href="https://chat.whatsapp.com/KPCI0oMm3psBuTxKhtILPB" target="_blank" >
                    <button class="btn btn-danger" style="background:#613EEA;border:1px solid #613EEA; border-radius: 6px;" id="fontcss"><img src="{{asset('public/whatsapp.png')}}" style="height:40px;border-radius:50%"> /whatsapp.com</button>
                </a>
            </div>
        </div>
    </div>
    <div class="container pt-4 mt-4">
        <div class="row">
            <div class="col-md-12" style="text-align: center;">
                <p class="p-0 pb-2 m-0" style="color: black;font-size: 22px;">What's App Community</p>
                <a href="https://chat.whatsapp.com/E2yAfK1Aetb8I3D0alRPXO" target="_blank" >
                    <button class="btn btn-danger" style="background:#613EEA;border:1px solid #613EEA; border-radius: 6px;" id="fontcss"><img src="{{asset('public/whatsapp.png')}}" style="height:40px;border-radius:50%"> /whatsapp.com</button>
                </a>
            </div>
        </div>
    </div>

</div>

{!! App\Models\Basicinfo::first()->chat_box !!}


@endsection
