@extends('user.master')

@section('maincontent')
@section('title')
    {{ env('APP_NAME') }}-Track Order
@endsection

    <div class="container">
        <div class="row">
            <div class="pt-4 mt-3 col-12">
                <div class="pb-4 card card-body search-area" style="border-radius: 16px;">
                    <h4 class="pb-2 m-0 text-left"> <b>Track You Order Now</b> </h4>
                    <form method="GET" action="{{ url('track-now') }}">
                        <label for="">Order ID</label>
                        <div class="form-group">
                            <input class="form-control" name="invoiceID" placeholder="Enter your ORDER ID" style="border-radius: 4.734px;border: 1.183px solid var(--dGrey-01, #E4E9EE);width: 100%;">
                        </div>
                        <button type="submit" class="btn btn-info" style="    width: 100%;border-radius: 6px;">
                            Search Now
                        </button>
                    </form>
                </div>
            </div>

            <div class="col-12">
            @if ($orders == 'Nothing')
            @else
                @if (isset($orders))
                    {{-- track list --}}
                    <div class="mt-4 card" style="border-radius:16px;">
                        <div class="clearfix px-3 py-2 card-header heading-6 strong-600">
                            <div class="float-center" style="color: red;text-align:center"> <b>Order History</b> </div>
                        </div>
                        <div class="clearfix px-3 py-2 card-header heading-6 strong-600">
                            <ul class="clearfix process-steps">
                                @if ($orders->status == 'Pending')
                                    <li>
                                        <div class="icon" style="background:#e62e04;color:white">1</div>
                                        <div class="title" style="color:red">On Processing</div>
                                    </li>
                                @else
                                    <li>
                                        <div class="icon">1</div>
                                        <div class="title">On Processing</div>
                                    </li>
                                @endif
                                @if ($orders->status == 'Confirmed')
                                    <li>
                                        <div class="icon" style="background:#e62e04;color:white">2</div>
                                        <div class="title" style="color:red">Confirmed</div>
                                    </li>
                                @else
                                    <li>
                                        <div class="icon">2</div>
                                        <div class="title">Confirmed</div>
                                    </li>
                                @endif

                                @if ($orders->status == 'Invoiced' || $orders->status == 'On Delivery')
                                    <li>
                                        <div class="icon" style="background:#e62e04;color:white">3</div>
                                        <div class="title" style="color:red">On Going</div>
                                    </li>
                                @else
                                    <li>
                                        <div class="icon">3</div>
                                        <div class="title">On Going</div>
                                    </li>
                                @endif

                                @if ($orders->status == 'Paid' || $orders->status == 'Delivered')
                                    <li>
                                        <div class="icon" style="background:#e62e04;color:white">4</div>
                                        <div class="title" style="color:red">Delivered</div>
                                    </li>
                                @else
                                    @if ($orders->status == 'Canceled' || $orders->status == 'Return')
                                        <li>
                                            <div class="icon" style="background:#e62e04;color:white">4</div>
                                            <div class="title" style="color:red">Canceled</div>
                                        </li>
                                    @else
                                        <li>
                                            <div class="icon">4</div>
                                            <div class="title">Delivered</div>
                                        </li>
                                    @endif

                                @endif

                            </ul>
                        </div>

                        <div class="pb-0 card-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <table class="table details-table">
                                        <tbody>
                                            <tr>
                                                <td class="w-50 strong-600">Order ID:</td>
                                                <td>{{ $orders->invoiceID }}</td>
                                            </tr>
                                            <tr>
                                                <td class="w-50 strong-600">Customer:</td>
                                                <td>{{ $orders->customers->customerName }}</td>
                                            </tr>
                                            <tr>
                                                <td class="w-50 strong-600">Phone:</td>
                                                <td>*******{{ substr ($orders->customers->customerPhone, -4) }}</td>
                                            </tr>
                                            <tr>
                                                <td class="w-50 strong-600">Shipping address:</td>
                                                <td>{{ $orders->customers->customerAddress }},@if (isset($orders->zones))
                                                        {{ $orders->zones->zoneName }},
                                                    @else
                                                        @endif @if (isset($orders->cities))
                                                            {{ $orders->cities->cityName }},
                                                        @else
                                                        @endif
                                                </td>
                                            </tr>
                                                <tr>
                                                <td class="w-50 strong-600">Shipping company:</td>
                                                <td>
                                                    @if (isset($orders->couriers))
                                                        {{ $orders->couriers->courierName }}
                                                    @else
                                                    @endif
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="col-lg-6">
                                    <table class="table details-table">
                                        <tbody>
                                            <tr>
                                                <td class="w-50 strong-600">Order date:</td>
                                                <td>{{ $orders->created_at->format('Y-m-d') }} ,
                                                    {{ date('h:i A', strtotime($orders->created_at)) }}</td>
                                            </tr>
                                            <tr>
                                                <td class="w-50 strong-600">Total order amount:</td>
                                                @if($orders->paymentAmount=='')
                                                    <td>৳ {{$orders->subTotal}} + <span style="color: red">( Charge : {{ $orders->deliveryCharge}} ৳)</span> </td>
                                                @elseif($orders->paymentAmount>0 && $orders->paymentAmount==$orders->deliveryCharge)
                                                    <td>৳ {{$orders->subTotal}} + <span style="color: red">( Charge : {{ $orders->deliveryCharge}} ৳)</span> </td>
                                                @elseif($orders->paymentAmount>0 && $orders->paymentAmount>$orders->deliveryCharge)
                                                    <td>৳ {{$orders->subTotal+$orders->paymentAmount-$orders->deliveryCharge}} + <span style="color: red">( Charge : {{ $orders->deliveryCharge}} ৳)</span> </td>
                                                @else
                                                    <td>৳ {{$orders->subTotal}} + <span style="color: red">( Charge : {{ $orders->deliveryCharge}} ৳)</span> </td>
                                                @endif

                                            </tr>

                                            <tr>
                                                <td class="w-50 strong-600">Payment method:</td>
                                                <td>
                                                    @if ($orders->Payment == 'C-O-D')
                                                        Cash On Delivery
                                                    @else
                                                        Online Payment
                                                    @endif
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="w-50 strong-600">Paid:</td>
                                                <td>
                                                    @if($orders->paymentAmount>0)
                                                        {{$orders->paymentAmount}} TK
                                                    @else
                                                        00 TK
                                                    @endif
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="w-50 strong-600">Due:</td>
                                                <td>
                                                    @if($orders->paymentAmount=='')
                                                        {{$orders->subTotal+$orders->deliveryCharge}} TK
                                                    @elseif($orders->paymentAmount>0 && $orders->paymentAmount==$orders->deliveryCharge)
                                                        {{$orders->subTotal}} TK
                                                    @elseif($orders->paymentAmount>0 && $orders->paymentAmount>$orders->deliveryCharge)
                                                        {{$orders->subTotal}} TK
                                                    @else
                                                        {{$orders->subTotal+$orders->deliveryCharge}} TK
                                                    @endif
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="mt-4 card" style="border-radius:16px;">

                        <div class="p-4 card-body">
                            <div class="col-12">
                                <table class="table details-table">
                                    <tbody>
                                        @forelse ($orders->orderproducts as $products)
                                            <tr>
                                                <td class="w-50 strong-600">Product Name:</td>
                                                <td>{{ $products->productName }} &nbsp; <span style="color: red">(
                                                        {{ $products->quantity }}
                                                        pics )</span>
                                                </td>
                                            </tr>
                                        @empty
                                        @endforelse
                                        <tr>
                                            <td class="w-50 strong-600"><b>Courier Tracking Url:</b></td>
                                            <td>@if(isset($orders->trackingLink)) {{ $orders->trackingLink }} @else None @endif   &nbsp;&nbsp; <button class="btn btn-info btn-sm" id="copyreflink" style="border-radius:4px;">Copy</button>
                                                <input type="text" value="{{$orders->trackingLink}}" id="referrallink" hidden style="color: black;width: 100%; border: none; font-weight: bold;">
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                @else
                    <div class="mt-4 card" style="border-radius: 4.734px;border: 1.183px solid var(--dGrey-01, #E4E9EE);background: #F3F3F3;">
                        <div class="clearfix px-3 py-2 card-header heading-6 strong-600">
                            <div class="float-left" style="color: red;text-align:center">No Records Found.Please call
                                our customer care or use Live Chat
                            </div>
                        </div>
                    </div>
                @endif
            @endif
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {

            $(document).on('click', '#copyreflink', function(e) {
                var copyText = document.getElementById("referrallink");

                copyText.select();
                copyText.setSelectionRange(0, 99999);
                navigator.clipboard
                    .writeText(copyText.value)
                    .then(() => {
                        alert("Successfully copied order tracking link");
                    })
                    .catch(() => {
                        alert("something went wrong");
                    });
            });

        });
    </script>

<style>
    .process-steps {
        margin: 0;
        padding: 0;
        list-style: none;
    }

    .process-steps li {
        width: 25%;
        float: left;
        text-align: center;
        position: relative;
    }

    .process-steps li .icon {
        height: 30px;
        width: 30px;
        margin: auto;
        background: #fff;
        border-radius: 50%;
        line-height: 30px;
        font-size: 14px;
        font-weight: 700;
        color: #adadad;
        position: relative;
    }

    .process-steps li .title {
        font-weight: 600;
        font-size: 13px;
        color: #777;
        margin-top: 8px;
        margin-bottom: 0;
    }

    .process-steps li+li:after {
        position: absolute;
        content: "";
        height: 3px;
        width: calc(100% - 30px);
        background: #fff;
        top: 14px;
        z-index: 0;
        right: calc(50% + 15px);
    }

    .breadcrumb {
        padding: 5px 0;
        border-bottom: 1px solid #e9e9e9;
        background-color: #fafafa;
    }

    .search-area .search-button {
        border-radius: 0px 3px 3px 0px;
        display: inline-block;
        float: left;
        margin: 0px;
        padding: 5px 15px 6px;
        text-align: center;
        background-color: #e62e04;
        border: 1px solid #e62e04;
    }

    .search-area .search-button:after {
        color: #fff;
        content: "\f002";
        font-family: fontawesome;
        font-size: 16px;
        line-height: 9px;
        vertical-align: middle;
    }
</style>

@endsection
