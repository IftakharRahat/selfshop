
<div id="posit" type="button" onclick="checkcartview()">
    <span style="font-size: 24px;line-height: 50px;color: red;">{{ count($cartProducts) }}</span><img src="{{ asset('public/ecommerce.png') }}" style="margin-top: -7px;height:40px;">
</div>

