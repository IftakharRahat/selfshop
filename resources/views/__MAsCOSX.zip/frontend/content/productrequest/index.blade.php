@extends('user.master')

@section('maincontent')
@section('meta')
    <title>{{\App\Models\Basicinfo::first()->title}}-User Profile</title>
    <meta name="description" content="{{\App\Models\Basicinfo::first()->meta_description}}">
    <meta name="keywords" content="{{\App\Models\Basicinfo::first()->meta_keyword}}">

    <meta property="og:image" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}" />

    <meta itemprop="name" content="{{\App\Models\Basicinfo::first()->title}}">
    <meta itemprop="description" content="{{\App\Models\Basicinfo::first()->meta_description}}">
    <meta itemprop="image" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}">

    <meta property="og:url" content="{{url('/')}}">
    <meta property="og:type" content="website">
    <meta property="og:title" content="{{\App\Models\Basicinfo::first()->title}}">
    <meta property="og:description" content="{{\App\Models\Basicinfo::first()->meta_description}}">
    <meta property="og:image" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}">
    <meta property="image" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}" />
    <meta property="url" content="{{url('/')}}">
    <meta name="robots" content="index, follow" />
    <meta itemprop="image" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}">
    <meta property="twitter:card" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}" />
    <meta property="twitter:title" content="{{\App\Models\Basicinfo::first()->title}}" />
    <meta property="twitter:url" content="{{url('/')}}">
    <meta name="twitter:image" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}">
@endsection


    <div class="container" style="padding-top:30px">
        <div class="mb-4 row">
            <div class="m-auto col-lg-12 col-12">
                <div class="card card-body" style="border: 1px solid #efefef !important;border-radius: 16px;">
                    <div style="padding: 0px;padding-left:6px;justify-content: space-around;">

                        <div class="row">
                            <div class="col-12">
                                <h4 class="d-flex justify-content-between">
                                    <span>Product request list </span>
                            </div>
                            <div class="mb-3 col-12">
                                <div class="card card-body" style="border-radius: 16px;">
                                    <form action="{{ url('user/productrequests') }}" enctype="multipart/form-data" method="post">
                                        @csrf
                                        <div class="form-group">
                                            <label for="">Product Name</label>
                                            <input type="text" name="p_name" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="">Image</label>
                                            <input type="file" name="attachment" class="form-control">
                                        </div>
                                        <button class="btn btn-success" style="border-radius: 6px;float: right;"> Save </button>
                                    </form>
                                </div>
                            </div>

                            <div class="col-12">
                                <table class="table table-striped">
                                    <tbody>
                                    @forelse ($products as $product)
                                        <tr>
                                            <th scope="row">
                                                <img src="{{ asset($product->attachment) }}" alt="" style="width:30px">
                                            </th>
                                            <td>{{ $product->p_name }}</td>
                                            <td>
                                                <button class="btn btn-info btn-sm" style="border-radius: 4px;">{{ $product->status }}</button>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <th  style="border-radius: 6px;text-align: center;"> No Records Found !</th>
                                        </tr>
                                    @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


@endsection
