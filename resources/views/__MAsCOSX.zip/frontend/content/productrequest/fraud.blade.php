@extends('user.master')

@section('maincontent')
@section('meta')
    <title>{{\App\Models\Basicinfo::first()->title}}-User Profile</title>
    <meta name="description" content="{{\App\Models\Basicinfo::first()->meta_description}}">
    <meta name="keywords" content="{{\App\Models\Basicinfo::first()->meta_keyword}}">

    <meta property="og:image" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}" />

    <meta itemprop="name" content="{{\App\Models\Basicinfo::first()->title}}">
    <meta itemprop="description" content="{{\App\Models\Basicinfo::first()->meta_description}}">
    <meta itemprop="image" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}">

    <meta property="og:url" content="{{url('/')}}">
    <meta property="og:type" content="website">
    <meta property="og:title" content="{{\App\Models\Basicinfo::first()->title}}">
    <meta property="og:description" content="{{\App\Models\Basicinfo::first()->meta_description}}">
    <meta property="og:image" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}">
    <meta property="image" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}" />
    <meta property="url" content="{{url('/')}}">
    <meta name="robots" content="index, follow" />
    <meta itemprop="image" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}">
    <meta property="twitter:card" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}" />
    <meta property="twitter:title" content="{{\App\Models\Basicinfo::first()->title}}" />
    <meta property="twitter:url" content="{{url('/')}}">
    <meta name="twitter:image" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}">
@endsection

<div class="body-content">
    <div class="container" style="padding-top:30px">

        <div class="mb-4 row">
            <div class="m-auto col-lg-12 col-12">
                <div class="card card-body" style="background: #FFF;border-radius: 16px;">
                    <div style="padding: 0px;padding-left:6px;justify-content: space-around;">
                        <div class="sideinfo">
                            <h4 class="d-flex justify-content-between">
                                <span>Fraud List: </span>
                                <a href="#" class="btn btn-info btn-sm"
                                    style="border-radius: 4px; font-size: 14px;"
                                    data-toggle="modal" data-target="#editPaymentModal">
                                        Add now
                                </a>
                            </h4>
                                <input type="text" style="border-radius: 4px" placeholder="Give phone number to check fraud" name="fraud_check" class="form-control" id="fraud_check" onkeyup="checkfraud()">
                            <br>
                            <div id="fraudlist">

                            </div>

                            <table class="table table-striped">
                                <tbody>
                                  @forelse ($fraudlists as $product)
                                    <tr>
                                        <td>
                                            <span style="color: green">#{{ $product->phone }}</span><br>{{ $product->message }}</td>
                                        <td style="text-align: right;">
                                            <button class="btn btn-info btn-sm" style="margin-top: 8px;border-radius: 4px;">{{ $product->status }}</button>
                                        </td>
                                    </tr>
                                  @empty
                                    <tr>
                                        <th style="text-align: center;"> No Records Found !</th>
                                    </tr>
                                  @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="editPaymentModal" tabindex="-1" aria-labelledby="editPaymentModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content" style="    border-radius: 8px;">
      <div class="modal-body">
         <div class="card card-body" style="border: none">
            <div class="d-flex" style="justify-content: space-between">
                <h4>Customer</h4>
                <a type="button" data-dismiss="modal" style="color: red" aria-label="Close">
                    <i class="fas fa-window-close"></i>
                </a>
            </div>

            <form action="{{ url('user/frauds') }}" enctype="multipart/form-data" method="post">
                @csrf
                <div class="form-group">
                    <label for="">Customer phone number</label>
                    <input type="text" name="phone" class="form-control">
                </div>
                <div class="form-group">
                    <label for=""> Customer description</label>
                    <input type="text" name="message" class="form-control">
                </div>
                <button class="btn btn-success" style="width:100%;border-radius: 4px;float: right;"> Save </button>
            </form>
        </div>
      </div>
    </div>
  </div>
</div>


<script>
    function checkfraud(){
        var fraud =$('#fraud_check').val();
        $.ajax({
            type: 'GET',
            url: 'check-fraud/' + fraud,

            success: function(response) {
                $('#fraudlist').empty().append(response);
            },
            error: function(error) {
                console.log('error');
            }

        });
    }
</script>


@endsection
