@extends('user.master')

@section('maincontent')

@section('title')
    {{ env('APP_NAME') }}- Support Tickets
@endsection
<style>
    a {
        color: black;
        text-decoration: none;
    }

    span.select2.select2-container.select2-container--default {
        width: 80px !important;
    }

    #titlename {
        text-align: center;
        padding: 10px;
        text-transform: uppercase;
        background: gray;
        color: white;
        border-radius: 3px;
    }

    div {
        color: black;
    }

    #accountbtn {
        width: 50%;
        padding: 10px;
        font-size: 22px;
    }

    #pb30 {
        padding-bottom: 50px;
    }

    .ptlg {
        padding-top: 74px;
    }

    .ticket-title {
        font-weight: 600;
        font-size: 20px;
        margin-bottom: 20px;
    }
    .table {
        border-collapse: separate;
        border-spacing: 0 10px;
    }
    .table thead th {
        border: none;
        color: #7a7a7a;
        font-weight: 500;
        font-size: 14px;
    }
    .table tbody tr {
        background: white;
    }
    .table tbody td {
        border-top: none;
        border-bottom: 1px solid #eee;
        font-size: 14px;
        vertical-align: middle;
    }
    .status-badge {
        padding: 4px 12px;
        border-radius: 4px;
        font-size: 13px;
        font-weight: 500;
        display: inline-block;
    }
    .status-accepted {
        background-color: #d4f8d4;
        color: #000;
    }
    .status-not {
        background-color: #ffe4b8;
        color: #ff9800;
    }
    .status-claim {
        background-color: #d4f8d4;
        color: #000;
    }
    .sort-dropdown {
        border-radius: 8px;
        border: 1px solid #ddd;
        padding: 4px 8px;
        font-size: 14px;
        background: #fff;
    }

    @media only screen and (max-width: 600px) {
        #accountbtn {
            width: 100%;
            padding: 10px;
            font-size: 22px;
        }
        .table th, .table td {
            padding: 0.25rem;
            vertical-align: top;
            border-top: 1px solid #EDF1FF;
        }

        .ptlg {
            padding-top: 0px;
        }
    }
</style>
<div class="container pt-4">
    <div class="row">
        <div class="col-12 col-lg-12">
            <div class="mb-3 d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="mb-0 ticket-title">All Tickets</h5>
                </div>
                <div class="gap-2 d-flex align-items-center">
                    <a href="{{ route('supporttikits.create') }}" class="btn btn-primary" style="height: 40px;color:white;border-radius:6px;">Create New
                    Ticket</a>
                </div>
            </div>

            <table class="table">
                <thead>
                    <tr>
                        <th>Department</th>
                        <th>Subject</th>
                        <th>Last Update</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($tikits as $tikit)
                        <tr>
                            <td>
                                <a href="{{ route('supporttikits.show', $tikit->id) }}">
                                    <span
                                        style="float: left;color: green;font-weight: bold;">#000{{ $tikit->id }}</span>
                                    <br><span style="float: left;">{{ $tikit->department }}</span>
                                </a>
                            </td>
                            <td style="width: 40%">
                                <a href="{{ route('supporttikits.show', $tikit->id) }}" style="    text-align: center;">
                                    <span class="d-lg-none d-block" style="float: left;color: green;font-weight: bold;">#000{{ $tikit->id }}</span>
                                    <br><span style="float: inline-end;">{{ $tikit->subject }}</span>
                                </a>
                            </td>
                            <td>
                                <a href="{{ route('supporttikits.show', $tikit->id) }}">
                                    {{ $tikit->updated_at->diffForHumans() }}
                                </a>
                            </td>
                            <td>
                                <a href="{{ route('supporttikits.show', $tikit->id) }}">
                                    @if($tikit->status=='Pending')
                                    <span class="status-badge status-claim">{{$tikit->status}}</span>
                                    @elseif($tikit->status=='Closed')
                                    <span class="status-badge status-not">{{$tikit->status}}</span>
                                    @else
                                    <span class="status-badge status-accepted">{{$tikit->status}}</span>
                                    @endif
                                </a>
                            </td>
                        </tr>
                    @empty
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>


@endsection
