@extends('frontend.master')

@section('maincontent')
@section('title')
    {{ env('APP_NAME') }}-Help & Support
@endsection
 <style>
    .about-section {
      background: url('public/aboutbanner.png') no-repeat center center;
      background-size: cover;
      position: relative;
      padding: 70px 0;
      color: #fff;
    }

    .about-footer-section {
      background: linear-gradient(0deg, rgba(132, 3, 56, 0.37) 0%, rgba(132, 3, 56, 0.37) 100%),
              url('public/aboutfooter.jpg');
      background-size: cover;
      position: relative;
      padding: 100px 0;
      color: #fff;
    }

    .about-section::before {
      content: '';
      position: absolute;
      inset: 0;
      background: rgba(0, 0, 0, 0.6); /* Dark overlay */
      z-index: 0;
    }

    .about-content {
      position: relative;
      z-index: 1;
      max-width: 900px;
      margin: auto;
    }

    .about-title {
      font-weight: 700;
      font-size: 3rem;
    }

    .about-text {
        font-size: 1.2rem;
        line-height: 1.5;
        margin-top: 20px;
        text-align: justify;
    }

    @media (max-width: 768px) {
      .about-title {
        font-size: 2rem;
      }

      .about-text {
        font-size: 1rem;
      }
    }

    .line {
        position: absolute;
        left: 50%;
        top: 0;
        width: 2px;
        height: 100%;
        background-color: white; /* Or any color */
        opacity: 0.8;
    }

  </style>


    <div class="container py-5 mt-4">
        <div class="row">
            <div class="col-lg-6">
                <img src="{{asset('public/h1.png')}}" alt="" style="width:100%">
            </div>
            <div class="mt-4 col-lg-6">
                <h2 style="text-align:left"><b>Call Center</b></h2>
                <p style="font-size: 18px;color:black;text-align:justify">
                    Lorem ipsum dolor sit amet consectetur. Faucibus tempus lacus ultrices eu. Tristique nunc morbi viverra nec malesuada amet a consectetur.
                </p>
                <a href="tel:{{ App\Models\Basicinfo::first()->phone_one }}" class="btn btn-info" style="border-radius: 4.707px;">Contact Now</a>
            </div>
        </div>
    </div>
    <div class="container py-5 mt-4">
        <div class="row">
            <div class="mt-4 col-lg-6">
                <h2 style="text-align:left"><b>Mail Us</b></h2>
                <p style="font-size: 18px;color:black;text-align:justify">
                    Lorem ipsum dolor sit amet consectetur. Faucibus tempus lacus ultrices eu. Tristique nunc morbi viverra nec malesuada amet a consectetur.
                </p>
                <a href="mailto:{{ App\Models\Basicinfo::first()->email }}" class="btn btn-info" style="border-radius: 4.707px;">Contact Now</a>
            </div>
            <div class="col-lg-6">
                <img src="{{asset('public/h2.png')}}" alt="" style="width:100%">
            </div>
        </div>
    </div>

    <div class="container py-5 mt-4">
        <div class="row">
            <div class="col-lg-6">
                <img src="{{asset('public/h2.png')}}" alt="" style="width:100%">
            </div>
            <div class="mt-4 col-lg-6">
                <h2 style="text-align:left"><b>Our Page</b></h2>
                <p style="font-size: 18px;color:black;text-align:justify">
                    Lorem ipsum dolor sit amet consectetur. Faucibus tempus lacus ultrices eu. Tristique nunc morbi viverra nec malesuada amet a consectetur.
                </p>
                <a href="https://www.facebook.com/selfshop.reseller" class="btn btn-info" style="border-radius: 4.707px;">Contact Now</a>
            </div>
        </div>
    </div>
    <div class="container py-5 mt-4">
        <div class="row">
            <div class="mt-4 col-lg-6">
                <h2 style="text-align:left"><b>Facebook Group</b></h2>
                <p style="font-size: 18px;color:black;text-align:justify">
                    Lorem ipsum dolor sit amet consectetur. Faucibus tempus lacus ultrices eu. Tristique nunc morbi viverra nec malesuada amet a consectetur.
                </p>
                <a href="https://www.facebook.com/groups/selfshopltd" class="btn btn-info" style="border-radius: 4.707px;">Contact Now</a>
            </div>
            <div class="col-lg-6">
                <img src="{{asset('public/h3.png')}}" alt="" style="width:100%">
            </div>
        </div>
    </div>

    <div class="container py-5 mt-4">
        <div class="row">
            <div class="col-lg-6">
                <img src="{{asset('public/h4.png')}}" alt="" style="width:100%">
            </div>
            <div class="mt-4 col-lg-6">
                <h2 style="text-align:left"><b>Messanger Group</b></h2>
                <p style="font-size: 18px;color:black;text-align:justify">
                    Lorem ipsum dolor sit amet consectetur. Faucibus tempus lacus ultrices eu. Tristique nunc morbi viverra nec malesuada amet a consectetur.
                </p>
                <a href="https://www.facebook.com/selfshop.reseller" class="btn btn-info" style="border-radius: 4.707px;">Contact Now</a>
            </div>
        </div>
    </div>
    <div class="container py-5 mt-4">
        <div class="row">
            <div class="mt-4 col-lg-6">
                <h2 style="text-align:left"><b>What's App Group</b></h2>
                <p style="font-size: 18px;color:black;text-align:justify">
                    Lorem ipsum dolor sit amet consectetur. Faucibus tempus lacus ultrices eu. Tristique nunc morbi viverra nec malesuada amet a consectetur.
                </p>
                <a href="https://chat.whatsapp.com/KPCI0oMm3psBuTxKhtILPB" class="btn btn-info" style="border-radius: 4.707px;">Contact Now</a>
            </div>
            <div class="col-lg-6">
                <img src="{{asset('public/h5.png')}}" alt="" style="width:100%">
            </div>
        </div>
    </div>

     <div class="container py-5 mt-4">
        <div class="row">
            <div class="col-lg-6">
                <img src="{{asset('public/h6.png')}}" alt="" style="width:100%">
            </div>
            <div class="mt-4 col-lg-6">
                <h2 style="text-align:left"><b>What's App Community</b></h2>
                <p style="font-size: 18px;color:black;text-align:justify">
                    Lorem ipsum dolor sit amet consectetur. Faucibus tempus lacus ultrices eu. Tristique nunc morbi viverra nec malesuada amet a consectetur.
                </p>
                <a href="https://chat.whatsapp.com/E2yAfK1Aetb8I3D0alRPXO" class="btn btn-info" style="border-radius: 4.707px;">Contact Now</a>
            </div>
        </div>
    </div>

    <br>
    <br>
    <br>
@endsection
