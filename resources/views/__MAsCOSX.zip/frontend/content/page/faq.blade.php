@extends('user.master')

@section('maincontent')
<style>
    .card-body {
        flex: 1 1 auto;
        min-height: 1px;
        padding: 1.25rem;
        border-radius: 0px 0px 4.734px 4.734px;
        border: 1.183px solid #E4E9EE;
        background: rgba(244, 244, 244, 0.47);
        margin-top: -4px;
        border-top: 0px;
    }
</style>
<div style="padding-top:30px;" class="body-content">
    <div class="container" style="padding-bottom:20px;">
        <div class="row">
            <div class="m-auto col-12 col-lg-10 text-ceter">
                <h4 class="text-center"><b>Frequently Asked Questions</b></h4>
                <p class="text-center" style="color: black">Lorem ipsum dolor sit amet consectetur. Dignissim erat odio dictum curabitur donec at consequat arcu cursus. Eget quis cum amet iaculis orci non.</p>
            </div>
        </div>
    </div>

    @php
        $faqs=App\Models\Faq::where('status','Active')->get();
    @endphp
    <div class="container" style="padding-bottom: 40px;">
        <div class="row">
            @forelse ($faqs as $key=>$faq)
                <div class="mb-2 col-md-12">
                    <h4 style="color: #000;border: 1px solid #cbc8c8;margin: 0;padding: 15px;font-size: 16px;border-radius: 4.734px;border: 1.183px solid var(--dGrey-01, #E4E9EE);background: rgba(244, 244, 244, 0.47); cursor: pointer;"
                        data-toggle="collapse" data-target="#collapseExample{{ $key }}">
                        {{ $faq->question }}
                        <span class="toggle-icon" style="float:right;font-weight:bold;font-size:18px;">+</span>
                    </h4>

                    <div class="collapse" id="collapseExample{{ $key }}">
                        <div class="card card-body">
                            {{ $faq->answer }}
                            @if(isset($faq->youtube_embade))
                                <br>
                                <iframe width="100%" height="150px"
                                        src="https://www.youtube.com/embed/{{$faq->youtube_embade}}">
                                </iframe>
                            @endif
                        </div>
                    </div>
                </div>

            @empty

            @endforelse
        </div>
    </div>

</div>
<script>
    $(document).ready(function(){
    // First item open by default
    $('#collapseExample0').addClass('show')
        .prev('h4').find('.toggle-icon').text('-');

    // Change icon on toggle
    $('.collapse').on('show.bs.collapse', function(){
        $(this).prev('h4').find('.toggle-icon').text('-');
    }).on('hide.bs.collapse', function(){
        $(this).prev('h4').find('.toggle-icon').text('+');
    });
});

</script>
@endsection
