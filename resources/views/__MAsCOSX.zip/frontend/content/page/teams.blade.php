@extends('user.master')

@section('maincontent')
<style>
        .team-card {
        text-align: center;
        padding: 20px;
        position: relative;
    }
    .blob-bg {
        position: absolute;
        top: 50%;
        left: 50%;
        width: 180px;
        height: 180px;
        background: #ffeef6;
        border-radius: 50% 40% 60% 50%;
        transform: translate(-50%, -50%);
        z-index: 0;
    }
    .team-img {
        position: relative;
        z-index: 1;
        width: 150px;
        height: 150px;
        border-radius: 50%;
        object-fit: cover;
        border: 5px solid #fff;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    .team-name {
        font-weight: 700;
        margin-top: 15px;
        font-size: 18px;
    }
    .team-role {
        font-size: 14px;
        color: #888;
        margin-bottom: 15px;
    }
    .social-icons a {
        display: inline-flex;
        justify-content: center;
        align-items: center;
        width: 35px;
        height: 35px;
        margin: 0 5px;
        border-radius: 50%;
        background-color: #f4f4f4;
        color: #000;
        font-size: 14px;
        transition: 0.3s;
        text-decoration: none;
    }
    .social-icons a:hover {
        background-color: #ff4f81;
        color: #fff;
    }
</style>
<div style="padding-top:20px;" class="body-content">
    <div class="container" style="padding-bottom:20px;">
        <div class="row">
            <div class="col-12 text-ceter">
                <h4 class="text-center">Team Members</h4>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            @forelse ($teams as $key=>$team)
                <div class="col-md-4 col-sm-6">
                    <div class="team-card">
                        @if(isset($team->profile))
                        <img src="{{asset($team->profile)}}" class="team-img" alt="Team Member">
                        @else
                        <img src="{{asset('public/user.jpg')}}" class="team-img" alt="Team Member">
                        @endif

                        <h5 class="team-name">{{$team->name}}</h5>
                        <p class="mb-0 team-role">{{$team->my_referral_code}}</p>
                        <p class="team-role">Join Date: {{$team->created_at->format('Y-m-d')}}</p>
                    </div>
                </div>
            @empty
                <div class="text-center card card-body">
                    No Member Found
                </div>
            @endforelse
        </div>
        {{$teams->links('pagination::bootstrap-4')}}
    </div>

</div>
<script>
    $(document).ready( function(){
        $('#collapseExample0').addClass('collapse show');
    });
</script>
@endsection
