@extends('user.master')

@section('maincontent')
@section('meta')
    <title>{{\App\Models\Basicinfo::first()->title}}-Developers</title>
    <meta name="description" content="{{\App\Models\Basicinfo::first()->meta_description}}">
    <meta name="keywords" content="{{\App\Models\Basicinfo::first()->meta_keyword}}">

    <meta property="og:image" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}" />

    <meta itemprop="name" content="{{\App\Models\Basicinfo::first()->title}}">
    <meta itemprop="description" content="{{\App\Models\Basicinfo::first()->meta_description}}">
    <meta itemprop="image" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}">

    <meta property="og:url" content="{{url('/')}}">
    <meta property="og:type" content="website">
    <meta property="og:title" content="{{\App\Models\Basicinfo::first()->title}}">
    <meta property="og:description" content="{{\App\Models\Basicinfo::first()->meta_description}}">
    <meta property="og:image" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}">
    <meta property="image" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}" />
    <meta property="url" content="{{url('/')}}">
    <meta name="robots" content="index, follow" />
    <meta itemprop="image" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}">
    <meta property="twitter:card" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}" />
    <meta property="twitter:title" content="{{\App\Models\Basicinfo::first()->title}}" />
    <meta property="twitter:url" content="{{url('/')}}">
    <meta name="twitter:image" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}">
@endsection

<div class="body-content">
    <div class="container" style="padding-top:30px">
        <div class="mb-4 row">
            <div class="m-auto col-lg-12 col-12">
                <div class="card card-body" style="background: #FFF;border-radius: 16px;padding:0;">
                    <div class="card-header d-flex justify-content-between" style="text-align: center;font-weight: bold;color: black;border-bottom: 0;">
                        <span style="line-height: 38px;">DEVELOPER API</span>
                        @if(isset($api))

                        @else
                            <a class="btn btn-info" style="border-radius:6px" href="{{url('generate-developers-api')}}"> Generate API</a>
                        @endif
                    </div>
                    @if(isset($api))
                        <table class="table">
                          <tbody>
                            <tr>
                              <th scope="row">SHOP NAME</th>
                              <td>{{ Auth::guard('web')->user()->shop_name }}</td>
                            </tr>
                            <tr>
                              <th scope="row">USER UUID</th>
                              <td class="d-flex"><span>{{base64_encode(Auth::user()->id)}}</span>  &nbsp; &nbsp;
                              <input type="text" value="{{base64_encode(Auth::user()->id)}}" id="referrallinkuser" hidden >
                              <button class="btn btn-info btn-sm" id="copyreflinkuser" style="border-radius: 4px;font-size: 12px;    height: 28px;"><i class="fa fa-clone"></i></button>
                              </td>
                            </tr>
                             <tr>
                              <th scope="row">API URL</th>
                              <td class="d-flex"><span>selfshop.com.bd/api/...</span>  &nbsp; &nbsp;
                              <input type="text" value="https://selfshop.com.bd/api/products" id="referrallinkurl" hidden >
                              <button class="btn btn-info btn-sm" id="copyreflinkurl" style="border-radius: 4px;font-size: 12px;    height: 28px;"><i class="fa fa-clone"></i></button>
                              </td>
                            </tr>
                            <tr>
                              <th scope="row">API KEY</th>
                              <td class="d-flex"><span class="d-none d-lg-block">{{$api->api_key}}</span> <span class="d-lg-none d-block">{{substr($api->api_key, 0, 20)}}</span>  &nbsp; &nbsp;
                              <input type="text" value="{{$api->api_key}}" id="referrallink" hidden >
                              <button class="btn btn-info btn-sm" id="copyreflink" style="border-radius: 4px;font-size: 12px;    height: 28px;"><i class="fa fa-clone"></i></button>
                              </td>
                            </tr>
                            <tr>
                              <th scope="row">API SECRET</th>
                              <td class="d-flex"><span class="d-none d-lg-block">{{$api->api_secret}}</span> <span class="d-lg-none d-block">{{substr($api->api_secret, 0, 20)}}</span>  &nbsp; &nbsp;
                              <input type="text" value="{{$api->api_secret}}" id="referrallinkss" hidden >
                              <button class="btn btn-info btn-sm" id="copyreflinkss" style="border-radius: 4px;font-size: 12px;    height: 28px;"><i class="fa fa-clone"></i></button>
                              </td>
                            </tr>
                            <tr>
                              <th scope="row">STATUS</th>
                              <td style="text-align: right"><button class="btn btn-success btn-sm" style="border-radius: 4px;padding: 4px 28px;">{{$api->status}}</button></td>
                            </tr>
                          </tbody>
                        </table>

                    @else

                    @endif
                </div>
            </div>
        </div>

    </div>
</div>

<script>
    $(document).ready(function() {

        $(document).on('click', '#copyreflink', function(e) {
            var copyText = document.getElementById("referrallink");

            copyText.select();
            copyText.setSelectionRange(0, 99999);
            navigator.clipboard
                .writeText(copyText.value)
                .then(() => {
                    alert("Successfully copied API key");
                })
                .catch(() => {
                    alert("something went wrong");
                });
        });

        $(document).on('click', '#copyreflinkurl', function(e) {
            var copyText = document.getElementById("referrallinkurl");

            copyText.select();
            copyText.setSelectionRange(0, 99999);
            navigator.clipboard
                .writeText(copyText.value)
                .then(() => {
                    alert("Successfully copied API url");
                })
                .catch(() => {
                    alert("something went wrong");
                });
        });

        $(document).on('click', '#copyreflinkuser', function(e) {
            var copyText = document.getElementById("referrallinkuser");

            copyText.select();
            copyText.setSelectionRange(0, 99999);
            navigator.clipboard
                .writeText(copyText.value)
                .then(() => {
                    alert("Successfully copied User UUID");
                })
                .catch(() => {
                    alert("something went wrong");
                });
        });

        $(document).on('click', '#copyreflinkss', function(e) {
            var copyText = document.getElementById("referrallinkss");

            copyText.select();
            copyText.setSelectionRange(0, 99999);
            navigator.clipboard
                .writeText(copyText.value)
                .then(() => {
                    alert("Successfully copied API secret");
                })
                .catch(() => {
                    alert("something went wrong");
                });
        });


    });
</script>

@endsection
