@extends('user.master')

@section('maincontent')
@section('meta')
    <title>{{\App\Models\Basicinfo::first()->title}}-User Profile</title>
    <meta name="description" content="{{\App\Models\Basicinfo::first()->meta_description}}">
    <meta name="keywords" content="{{\App\Models\Basicinfo::first()->meta_keyword}}">

    <meta property="og:image" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}" />

    <meta itemprop="name" content="{{\App\Models\Basicinfo::first()->title}}">
    <meta itemprop="description" content="{{\App\Models\Basicinfo::first()->meta_description}}">
    <meta itemprop="image" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}">

    <meta property="og:url" content="{{url('/')}}">
    <meta property="og:type" content="website">
    <meta property="og:title" content="{{\App\Models\Basicinfo::first()->title}}">
    <meta property="og:description" content="{{\App\Models\Basicinfo::first()->meta_description}}">
    <meta property="og:image" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}">
    <meta property="image" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}" />
    <meta property="url" content="{{url('/')}}">
    <meta name="robots" content="index, follow" />
    <meta itemprop="image" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}">
    <meta property="twitter:card" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}" />
    <meta property="twitter:title" content="{{\App\Models\Basicinfo::first()->title}}" />
    <meta property="twitter:url" content="{{url('/')}}">
    <meta name="twitter:image" content="{{ url(\App\Models\Basicinfo::first()->meta_image) }}">
@endsection

<div class="body-content">
    <div class="container" style="padding-top:30px">
        <div class="mb-4 row">
            <div class="m-auto col-lg-12 col-12">
                <div class="card card-body" style="border: 1px solid #613EEA !important;border-radius: 6px;">
                    <div class="d-flex" style="padding: 0px 20px;padding-left:6px;justify-content: space-around;">
                        @if (isset(Auth::user()->profile))
                            <img src="{{ asset(Auth::user()->profile) }}" style="margin-top: 0px;width: 80px;height:80px;border-radius: 50%;">
                        @else
                            <img src="{{ asset('public/user.jpg') }}" style="height:80px;width: 80px;margin-top: 0px;">
                        @endif
                        <div class="sideinfo">
                            <h4 class="p-0 m-0" style="height: 20px;overflow: hidden;font-size: 16px;margin-left: 10px !important;font-weight: bold;">{{ Auth::guard('web')->user()->name }} </h4>
                            <p class="p-0 m-0" style="margin-left: 10px !important;font-size:12px;">{{ Auth::guard('web')->user()->email }}</p>
                            <p class="p-0 m-0" style="margin-left: 10px !important;font-size:12px;">SHOP : {{ Auth::guard('web')->user()->shop_name }}</p>
                            <p class="p-0 m-0" style="margin-left: 10px !important;font-size:12px;">ID : {{ Auth::guard('web')->user()->my_referral_code }} &nbsp;&nbsp;&nbsp; <button class="btn btn-info btn-sm" id="copyreflink" style="border-radius: 4px;font-size: 12px;">COPY REFER LINK</button> </p>
                            <input type="text" value="{{ url('/register') }}/{{ Auth::user()->my_referral_code }}"
                                id="referrallink" hidden >
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="mb-4 row">
            <div class="m-auto col-lg-12 col-12">
                <div class="card card-body" style="border: 1px solid #613EEA !important;border-radius: 6px;">
                    <div style="padding: 0px 20px;padding-left:6px;justify-content: space-around;">
                        <div class="sideinfo">

                            @php
                                $bank=App\Models\Bank::where('user_id',Auth::user()->id)->first();
                            @endphp

                            <h4 class="p-0 m-0" style="height: 20px;overflow: hidden;font-size: 16px;font-weight: bold;">Bank Name : @if(isset($bank)) {{  $bank->bank_name }} @endif</h4>
                            <p class="p-0 m-0" style="font-size:12px;">Bank Acc Title :  @if(isset($bank)) {{  $bank->account_name }} @endif</p>
                            <p class="p-0 m-0" style="font-size:12px;">Bank Acc Number :  @if(isset($bank)) {{  $bank->account_number }} @endif</p>
                            <p class="p-0 m-0" style="font-size:12px;">Bank Routing Number :  @if(isset($bank)) {{  $bank->routing_number }} @endif</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="mb-4 row">
            <div class="m-auto col-lg-12 col-12">
                <div class="card card-body">
                    <table class="table table-striped">
                        <tbody>
                          <tr>
                            <th scope="row">Total Product In My Shop</th>
                            <td>{{App\Models\Shopproduct::where('user_id',Auth::user()->id)->get()->count()}}</td>
                          </tr>
                          <tr>
                            <th scope="row">Total Order</th>
                            <td>{{App\Models\Order::where('user_id',Auth::user()->id)->get()->count()}}</td>
                          </tr>
                          <tr>
                            <th scope="row">Total Sold Amount</th>
                            <td>৳ {{App\Models\Order::where('user_id',Auth::user()->id)->whereIn('status',['Delivered','Paid'])->get()->sum('subTotal')+App\Models\Order::where('user_id',Auth::user()->id)->whereIn('status',['Delivered','Paid'])->get()->sum('paymentAmount')}}</td>
                          </tr>
                          <tr>
                            <th scope="row">Wallet Balance</th>
                            <td>৳ {{Auth::user()->account_balance}}</td>
                          </tr>
                        </tbody>
                      </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {

        $(document).on('click', '#copyreflink', function(e) {
            var copyText = document.getElementById("referrallink");

            copyText.select();
            copyText.setSelectionRange(0, 99999);
            navigator.clipboard
                .writeText(copyText.value)
                .then(() => {
                    alert("Successfully copied referral link");
                })
                .catch(() => {
                    alert("something went wrong");
                });
        });

    });
</script>

@endsection
