<!-- Vendor JS Files -->
<script src="{{asset('public/admin/assets/')}}/vendor/bootstrap/js/bootstrap.bundle.js"></script>
<script src="{{asset('public/admin/assets/')}}/vendor/php-email-form/validate.js"></script>
<script src="{{asset('public/admin/assets/')}}/vendor/quill/quill.min.js"></script>
<script src="{{asset('public/admin/assets/')}}/vendor/tinymce/tinymce.min.js"></script>
<script src="{{asset('public/admin/assets/')}}/vendor/simple-datatables/simple-datatables.js"></script>
<script src="{{asset('public/admin/assets/')}}/vendor/chart.js/chart.min.js"></script>
<script src="{{asset('public/admin/assets/')}}/vendor/apexcharts/apexcharts.min.js"></script>
<script src="{{asset('public/admin/assets/')}}/vendor/echarts/echarts.min.js"></script>

<script src="//cdn.datatables.net/1.10.7/js/jquery.dataTables.min.js"></script>

<!-- Template Main JS File -->
<script src="{{asset('public/admin/assets/')}}/js/main.js"></script>
{{-- //ajax js for admin --}}
<script src="{{asset('public/admin/assets/')}}/js/admin.js"></script>
{{-- //sweetalert --}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js" integrity="sha512-AA1Bzp5Q0K1KanKKmvN/4d3IRKVlv9PYgwFPvm32nPO6QS8yH1HO7LbgB1pgiOxPtfeg5zEn2ba64MUcqJx6CA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

